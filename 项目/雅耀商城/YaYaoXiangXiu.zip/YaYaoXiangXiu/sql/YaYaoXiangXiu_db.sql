/*!40101 SET CHARACTER SET 'gbk' */;

DROP DATABASE IF EXISTS `YaYaoXiangXiu_db`;
CREATE DATABASE `YaYaoXiangXiu_db` /*!40100 DEFAULT CHARACTER SET gbk */;
USE `YaYaoXiangXiu_db`;

CREATE TABLE admin (
  ID int(4) NOT NULL auto_increment,
  AdminType int(4) default NULL,
  AdminName varchar(12) default NULL,
  LoginName varchar(12) default NULL,
  LoginPwd varchar(12) default NULL,
  PRIMARY KEY  (ID)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

INSERT INTO admin (ID,AdminType,AdminName,LoginName,LoginPwd) VALUES (1,1,'��Ʒ����Ա','shangpin','123456');
INSERT INTO admin (ID,AdminType,AdminName,LoginName,LoginPwd) VALUES (2,2,'��������Ա','dingdan','123456');
INSERT INTO admin (ID,AdminType,AdminName,LoginName,LoginPwd) VALUES (3,3,'��Ա����Ա','huiyuan','123456');
INSERT INTO admin (ID,AdminType,AdminName,LoginName,LoginPwd) VALUES (4,4,'ϵͳ����Ա','nieyue','nieaizhi');

CREATE TABLE cart (
  ID int(4) NOT NULL auto_increment,
  Member int(4) NOT NULL,
  Money decimal(9,2) default NULL,
  CartStatus int(4) default NULL,
  PRIMARY KEY  (ID)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

CREATE TABLE cartselectedmer (
  ID int(4) NOT NULL auto_increment,
  Cart int(4) NOT NULL,
  Merchandise int(4) NOT NULL,
  Number int(4) NOT NULL default 1,
  Price decimal(8,2) NOT NULL default 0.00,
  Money decimal(9,2) NOT NULL default 0.00,
  PRIMARY KEY  (ID)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

CREATE TABLE category (
  ID int(4) NOT NULL auto_increment,
  CateName char(40) default NULL,
  CateDesc text,
  PRIMARY KEY  (ID)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

CREATE TABLE leaveword (
  ID int(4) NOT NULL auto_increment,
  Member int(4) NOT NULL,
  Admin int(4) default NULL,
  Title char(60) default NULL,
  Content text,
  LeaveDate datetime default NULL,
  AnswerContent text,
  AnswerDate datetime default NULL,
  PRIMARY KEY  (ID)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

CREATE TABLE member (
  ID int(4) NOT NULL auto_increment,
  Memberlevel int(4) NOT NULL,
  LoginName char(12) default NULL,
  LoginPwd char(12) default NULL,
  MemberName char(20) default NULL,
  Phone char(15) default NULL,
  Address varchar(100) default NULL,
  Zip char(10) default NULL,
  RegDate datetime default NULL,
  LastDate datetime default NULL,
  LoginTimes int(4) default NULL,
  EMail varchar(100) default NULL,
  PRIMARY KEY  (ID)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

CREATE TABLE memberlevel (
  ID int(4) NOT NULL auto_increment,
  LevelName char(20) default NULL,
  Favourable int(5) default NULL,
  PRIMARY KEY  (ID)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

CREATE TABLE merchandise (
  ID int(4) NOT NULL auto_increment,
  Category int(4) NOT NULL,
  MerName char(40) default NULL,
  Price decimal(8,2) default NULL,
  SPrice decimal(8,2) default NULL,
  MerModel char(40) default NULL,
  Picture varchar(100) default NULL,
  MerDesc text,
  Manufacturer char(60) default NULL,
  LeaveFactoryDate datetime default NULL,
  Special int(4) default NULL,
  PRIMARY KEY  (ID)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

CREATE TABLE orders (
  ID int(4) NOT NULL auto_increment,
  Member int(4) NOT NULL,
  Cart int(4) NOT NULL,
  OrderNO char(20) default NULL,
  OrderDate datetime default NULL,
  OrderStatus int(4) default NULL,
  PRIMARY KEY  (ID)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

INSERT INTO memberlevel (ID,LevelName,Favourable) VALUES (1,'��ͨ��Ա',0);
INSERT INTO memberlevel (ID,LevelName,Favourable) VALUES (2,'��ͭ��Ա',88);
INSERT INTO memberlevel (ID,LevelName,Favourable) VALUES (3,'������Ա',288);
INSERT INTO memberlevel (ID,LevelName,Favourable) VALUES (4,'�ƽ��Ա',888);
INSERT INTO memberlevel (ID,LevelName,Favourable) VALUES (5,'�׽��Ա',2888);
INSERT INTO memberlevel (ID,LevelName,Favourable) VALUES (6,'��ʯ��Ա',8888);
INSERT INTO memberlevel (ID,LevelName,Favourable) VALUES (7,'�����Ա',28888);