package com.yayao.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.yayao.bean.Consignee;
import com.yayao.bean.ExclusiveCustom;
import com.yayao.dao.ConsigneeDao;
import com.yayao.dao.ExclusiveCustomDao;
import com.yayao.util.BaseLog;
@Repository("exclusiveCustomDao")
public class ExclusiveCustomDaoImpl extends BaseLog implements ExclusiveCustomDao {
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	public Session getSession() {
		//return sessionFactory.getCurrentSession();
		return sessionFactory.openSession();
		
	}
	/**
	 * 增加定制
	 */
	@Override
	public boolean addExclusiveCustom(ExclusiveCustom exclusiveCustom) throws Exception {
		boolean status = false;
		try{
			getSession().save(exclusiveCustom);
		status = true;
		return status;
		}catch(Exception e){
			e.printStackTrace();
			logger.info("在执行AdminServiceImpl类中的addAdmin方法时出错：\n");
		}
		finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}
		    return status;
	}
	
	/**
	 * 修改定制
	 */
	@Override
	public boolean updateExclusiveCustom(ExclusiveCustom exclusiveCustom) throws Exception {
		boolean status = false;
		Transaction tran=null;
		try{
			tran=getSession().beginTransaction();
			Query hql = getSession().createQuery(
					" UPDATE ExclusiveCustom "+ 
							" SET customCategory=?, "+
							" member=?, "+
							" customDate=?, "+
							" customName=?, "+
							" customPhone=?, "+
							" customPicture=?, "+
							" customDetails=?, "+
							" customOrderNumber=? "+
					" WHERE id=? ");
	
			hql.setString(0, exclusiveCustom.getCustomCategory());
			hql.setEntity(1, exclusiveCustom.getMember());
			hql.setString(2, exclusiveCustom.getCustomDate());
			hql.setString(3, exclusiveCustom.getCustomName());
			hql.setString(4, exclusiveCustom.getCustomPhone());
			hql.setString(5, exclusiveCustom.getCustomPicture());
			hql.setString(6, exclusiveCustom.getCustomDetails());
			hql.setString(7, exclusiveCustom.getCustomOrderNumber());
	
			
			hql.setInteger(8, exclusiveCustom.getId());
			hql.executeUpdate();
			tran.commit();
			status = true;
		}catch(Exception ex){
			tran.rollback();
			logger.info("在执行AdminServiceImpl类中的updateAdmin方法时出错：\n");
			ex.printStackTrace();
		}finally{
			
			getSession().flush();
			getSession().clear();
		    getSession().close();
		}
		return status;
	}

	/**
	 * 浏览定制信息
	 */
	@Override
	public List browseExclusiveCustom() throws Exception {
		Criteria c = getSession().createCriteria(ExclusiveCustom.class);		
		c.addOrder(Order.asc("id"));
		List list=c.list();
		getSession().flush();
		getSession().clear();
		getSession().close();
		//logger.info("在执行AdminServiceImpl类中的browseAdmin方法时出错：\n");
	return list;
	}

	/**
	 * 删除定制信息
	 */
	@Override
	public boolean delExclusiveCustom(Integer id) throws Exception {
		boolean status = false;
		Transaction tran=getSession().beginTransaction();
			try{
			Query hql = getSession().createQuery(" delete from ExclusiveCustom  where id=:id ");
			hql.setInteger("id", id);
			hql.executeUpdate();
			tran.commit();
			status = true;
			}catch(Exception e){
				tran.rollback();
				e.printStackTrace();
	        }finally{
	        	getSession().flush();
	        	getSession().clear();
	        	getSession().close();
	        }
			return status;
	}
	
	/**
	 * 装载收货人信息
	 */
	@Override
	public ExclusiveCustom loadExclusiveCustom(Integer id) throws Exception {
		ExclusiveCustom exclusiveCustom = (ExclusiveCustom)getSession().get(ExclusiveCustom.class, id);
		getSession().flush();
		getSession().clear();
		getSession().close();
		return exclusiveCustom;
	}
	/**
	 * 查询定制订单
	 */
	public List searchExclusiveCustom(String hql) throws Exception {
		List l=null;
		Transaction tran=null;
		try {
			tran=getSession().beginTransaction();
			Query q = getSession().createQuery(hql);
			l = q.list();
			tran.commit();
		} catch (Exception e) {
			tran.rollback();
			e.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}
		return l;
	}

}
