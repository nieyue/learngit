package com.yayao.dao;

import com.yayao.bean.*;
import java.util.*;

public interface OrderDao {
	/** 新增订单 */	
	public boolean addOrder(Orders order) throws Exception;
	/** 浏览某会员的所有订单 */
	public List browseOrder(Member member) throws Exception;
	/** 浏览所有订单 */
	public List browseOrder() throws Exception;
	/** 浏览某订单的所有商品记录 */
	public List browseOrderMer(Orders order) throws Exception;			
	/** 删除订单 */	
	public boolean delOrder(Integer id) throws Exception;	
	/** 装载订单 */	
	public Orders loadOrder(Integer id) throws Exception;
	/** 修改订单 */	
	public boolean updateOrder(Orders order) throws Exception;
	
}
