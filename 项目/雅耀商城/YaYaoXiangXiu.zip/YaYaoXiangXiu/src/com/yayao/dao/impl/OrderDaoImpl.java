package com.yayao.dao.impl;


import java.util.*;

import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.yayao.bean.*;
import com.yayao.dao.OrderDao;
import com.yayao.util.*;
@Repository("orderDao")
public class OrderDaoImpl extends BaseLog implements OrderDao {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	public Session getSession() {
		//return sessionFactory.getCurrentSession();
		return sessionFactory.openSession();
		
	}

	/** 新增订单 */
	public boolean addOrder(Orders order) throws Exception {
		Transaction tx = null;
		boolean status = false;
		try{
			tx = getSession().beginTransaction();
			getSession().save(order);
			tx.commit();
			status=true;
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行OrderServiceImpl类中的addOrder方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}		
		return status;
	}

	/** 浏览某会员的所有订单 */
	public List browseOrder(Member member) throws Exception {
		Transaction tx = null;
		List list = null;
		try{
			Query query = getSession().createQuery("from Orders as a where a.member=:member");
			tx = getSession().beginTransaction();
			query.setEntity("member", member);
			list = query.list();
			tx.commit();			
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行OrderServiceImpl类中的browseOrder方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}		
		return list;
	}

	/** 浏览所有订单 */
	public List browseOrder() throws Exception {
		Transaction tx = null;
		List list = null;
		try{
			Query query = getSession().createQuery("from Orders as a order by a.id desc");
			tx = getSession().beginTransaction();
			list = query.list();
			if (!Hibernate.isInitialized(list))Hibernate.initialize(list);
			tx.commit();			
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行OrderServiceImpl类中的browseOrder方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return list;
	}

	/** 浏览某订单的所有商品记录 */
	public List browseOrderMer(Orders order) throws Exception {
		Transaction tx = null;
		List result = null;
		try{
			//浏览购物车中的所有选购记录
			String hql ="from Cartselectedmer as a where a.order=:order";
			Query query = getSession().createQuery(hql);
			query.setEntity("order", order);
			tx = getSession().beginTransaction();
			result = query.list();
			tx.commit();
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行OrderServiceImpl类中的browseOrderMer方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return result;
	}

	/** 删除订单 */	
	public boolean delOrder(Integer id) throws Exception {
		Transaction tx = null;
		boolean status = false;
		try{
			tx = getSession().beginTransaction();
			Query hql=getSession().createQuery(" DELETE from Orders  WHERE id=:id ");
			hql.setInteger("id", id);
			hql.executeUpdate();
			tx.commit();
			status = true;
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行OrderServiceImpl类中的delOrder方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return status;
	}

	/** 装载订单 */
	public Orders loadOrder(Integer id) throws Exception {
		Transaction tx = null;
		Orders order = null;
		try{
			tx = getSession().beginTransaction();
			order = (Orders)getSession().get(Orders.class, id);
			tx.commit();
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行OrderServiceImpl类中的loadOrder方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return order;
	}

	/** 修改订单 */
	public boolean updateOrder(Orders order) throws Exception {
		Transaction tx = null;
		boolean status = false;
		try{
			tx = getSession().beginTransaction();
			Query hql = getSession().createQuery(
					" UPDATE Orders  o "+ 
							" SET o.orderNumber=?, "+
							" o.orderDate=?, "+
							" o.member=?, "+
							" o.cart=?, "+
							" o.consignee=? "+
					" WHERE o.id=? ");
			hql.setString(0, order.getOrderNumber());
			hql.setString(1, order.getOrderDate());
			hql.setEntity(2, order.getMember());
			hql.setEntity(3, order.getCart());
			hql.setEntity(4, order.getConsignee());
			hql.setInteger(5, order.getId());
			hql.executeUpdate();
			tx.commit();
			status=true;
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行OrderServiceImpl类中的updateOrder方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return status;
	}

}
