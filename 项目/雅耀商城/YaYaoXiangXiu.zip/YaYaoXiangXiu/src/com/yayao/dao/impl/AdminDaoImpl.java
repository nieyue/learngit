package com.yayao.dao.impl;

import java.util.List;

import com.yayao.bean.*;
import com.yayao.dao.AdminDao;
import com.yayao.util.BaseLog;












import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;


/** 系统用户管理接口实现 */
@Repository("adminDao")
public class AdminDaoImpl extends BaseLog implements AdminDao{
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	public Session getSession() {
		//return sessionFactory.getCurrentSession();
		return sessionFactory.openSession();
		
	}
	
	
	/** 系统管理员登录 */
	public Admin adminLogin(String loginName, String loginPwd) throws Exception {
			
		    Criteria c = getSession().createCriteria(Admin.class);
			c.add(Restrictions.eq("loginName", loginName));
			c.add(Restrictions.eq("loginPwd",loginPwd));
			Admin admin = (Admin) c.uniqueResult();
			getSession().flush();
			getSession().clear();
			getSession().close();
			return admin;
	}

	/** 新增管理员 */	
	
	public boolean addAdmin(Admin admin) {
		boolean status = false;
		try{
			getSession().save(admin);
		status = true;
		return status;
		}catch(Exception e){
			e.printStackTrace();
			logger.info("在执行AdminServiceImpl类中的addAdmin方法时出错：\n");
		}
		finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}
		    return status;
	}

	/** 浏览管理员 */
	public List browseAdmin() throws Exception {
//			Criteria c = getSession().createCriteria(Admin.class);		
//			c.addOrder(Order.asc("id"));
//			List admins=c.list();
		
		
		  List admins=null;
			Transaction tran=null;
			try{
				
			tran=getSession().beginTransaction();
			Query hql = getSession().createQuery("from Admin order by id desc");
			admins = hql.list();
			
			tran.commit();
			}catch(Exception e){
				tran.rollback();
				e.printStackTrace();
	        }finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
			}
			//logger.info("在执行AdminServiceImpl类中的browseAdmin方法时出错：\n");
		return admins;
	}

	/** 删除指定的管理员 
	 * @throws Exception */
	public boolean delAdmin(Integer id)  {
		boolean status = false;
		Transaction tran=null;
			try{
			//Admin admin = (Admin)getSession().get(Admin.class, id);
			//Criteria c = getSession().createCriteria(Admin.class);
			//c.add(Restrictions.eq("id", id));
			//Admin admin = (Admin) c.uniqueResult();
			//getSession().delete(admin);
			tran=getSession().beginTransaction();
			
			//Query q = getSession().createSQLQuery(" delete from admin_tb  where id=:id ");
			
			Query hql = getSession().createQuery(" delete from Admin as a  where a.id=:id");
			hql.setInteger("id", id);
			hql.executeUpdate();
			tran.commit();
			 
			status = true;
			}catch(Exception e){
				tran.rollback();
				e.printStackTrace();
	        }
			finally{
				
				getSession().flush();
				getSession().clear();
			    getSession().close();
			}
			return status;
	}
	/** 装载指定的管理员 */
	public Admin loadAdmin(Integer id) throws Exception {
		Transaction tran=getSession().beginTransaction();
		Admin admin = (Admin)getSession().get(Admin.class, id);
		getSession().flush();
		getSession().clear();
		getSession().close();
		return admin;
	}

	/** 更新管理员 */	
	public boolean updateAdmin(Admin admin) {
		
		boolean status = false;
		Transaction tran=null;
		try{
			tran=getSession().beginTransaction();
			
			/*Query q = getSession().createSQLQuery(
					" UPDATE admin_tb "+ 
                    " SET AdminType=?, "+ 
                    " AdminName=?, "+
                    " LoginName=?, "+ 
                    " LoginPwd =? "+ 
                    " WHERE ID=? ");
			q.setInteger(0, admin.getAdminType());
			q.setString(1, admin.getAdminName());
			q.setString(2, admin.getLoginName());
			q.setString(3, admin.getLoginPwd());
			q.setInteger(4, admin.getId());
			*/
			Query hql= getSession().createQuery("update Admin a set a.adminType=?,a.adminName=?,a.loginName=?,a.loginPwd=? where a.id=? ");
			hql.setInteger(0, admin.getAdminType());
			hql.setString(1, admin.getAdminName());
			hql.setString(2, admin.getLoginName());
			hql.setString(3, admin.getLoginPwd());
			hql.setInteger(4, admin.getId());
			hql.executeUpdate();
			tran.commit();
			
			status = true;
		}catch(Exception ex){
			tran.rollback();
			logger.info("在执行AdminServiceImpl类中的updateAdmin方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
		    getSession().close();
		}
		return status;
	}


	/**
	 * 检查管理员账号是否存在
	 */
	public boolean chkAdminLoginName(String loginName) throws Exception {
		boolean status = true;//true代表数据库已经存在
		Admin admin = null;
		Criteria c = getSession().createCriteria(Admin.class);
		c.add(Restrictions.eq("loginName", loginName));
		 admin = (Admin) c.uniqueResult();
		if(admin==null){
			status=false;
			return status;
		}
		 getSession().flush();
		getSession().clear();
		getSession().close();
		
		return status;
	}
}