package com.yayao.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.yayao.bean.Consignee;
import com.yayao.dao.ConsigneeDao;
import com.yayao.util.BaseLog;
@Repository("consigneeDao")
public class ConsigneeDaoImpl extends BaseLog implements ConsigneeDao {
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	public Session getSession() {
		//return sessionFactory.getCurrentSession();
		return sessionFactory.openSession();
		
	}
	/**
	 * 增加收货人
	 */
	@Override
	public boolean addConsignee(Consignee consignee) throws Exception {
		boolean status = false;
		try{
			getSession().save(consignee);
		status = true;
		return status;
		}catch(Exception e){
			e.printStackTrace();
			logger.info("在执行AdminServiceImpl类中的addAdmin方法时出错：\n");
		}
		finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}
		    return status;
	}
	
	/**
	 * 修改收货人信息
	 */
	@Override
	public boolean updateConsignee(Consignee consignee) throws Exception {
		boolean status = false;
		Transaction tran=null;
		try{
			tran=getSession().beginTransaction();
			/*Query q = getSession().createSQLQuery(
					" UPDATE consignee_tb "+ 
                    " SET ReceiptName=?, "+
					" TelePhone=?, "+
					" CellPhone=?, "+
					" Address=?, "+
					" Zip=? "+
                    " WHERE ID=? ");*/
			Query hql = getSession().createQuery(
					" UPDATE Consignee "+ 
							" SET receiptName=?, "+
							" telePhone=?, "+
							" cellPhone=?, "+
							" address=?, "+
							" hasOrder=?, "+
							" zip=? "+
					" WHERE id=? ");

			hql.setString(0, consignee.getReceiptName());
			hql.setString(1, consignee.getTelePhone());
			hql.setString(2, consignee.getCellPhone());
			hql.setString(3, consignee.getAddress());
			hql.setInteger(4, consignee.getHasOrder());
			hql.setString(5, consignee.getZip());
			hql.setInteger(6, consignee.getId());
			hql.executeUpdate();
			tran.commit();
			status = true;
		}catch(Exception ex){
			tran.rollback();
			logger.info("在执行AdminServiceImpl类中的updateAdmin方法时出错：\n");
			ex.printStackTrace();
		}finally{
			
			getSession().flush();
			getSession().clear();
		    getSession().close();
		}
		return status;
	}

	/**
	 * 浏览收货人信息
	 */
	@Override
	public List browseConsignee() throws Exception {
		Criteria c = getSession().createCriteria(Consignee.class);		
		c.addOrder(Order.asc("id"));
		List list=c.list();
		getSession().flush();
		getSession().clear();
		getSession().close();
		//logger.info("在执行AdminServiceImpl类中的browseAdmin方法时出错：\n");
	return list;
	}

	/**
	 * 删除收货人信息
	 */
	@Override
	public boolean delConsignee(Integer id) throws Exception {
		boolean status = false;
		Transaction tran=getSession().beginTransaction();
			try{
			//Query q = getSession().createSQLQuery(" delete from consignee_tb  where id=:id ");
			Query hql = getSession().createQuery(" delete from Consignee  where id=:id ");
			hql.setInteger("id", id);
			hql.executeUpdate();
			tran.commit();
			status = true;
			}catch(Exception e){
				tran.rollback();
				e.printStackTrace();
	        }finally{
	        	getSession().flush();
	        	getSession().clear();
	        	getSession().close();
	        }
			return status;
	}
	
	/**
	 * 装载收货人信息
	 */
	@Override
	public Consignee loadConsignee(Integer id) throws Exception {
		Consignee consignee = (Consignee)getSession().get(Consignee.class, id);
		getSession().flush();
		getSession().clear();
		getSession().close();
		return consignee;
	}

}
