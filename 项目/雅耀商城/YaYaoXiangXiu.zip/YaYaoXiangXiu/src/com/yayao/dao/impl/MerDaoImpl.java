package com.yayao.dao.impl;

import java.util.*;

import org.hibernate.*;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.yayao.bean.*;
import com.yayao.dao.MerDao;
import com.yayao.util.*;
@Repository("merDao")
public class MerDaoImpl extends BaseLog implements MerDao {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	public Session getSession() {
		//return sessionFactory.getCurrentSession();
		return sessionFactory.openSession();
		
	}

	/**
	 * 新增商品分类 
	 */
	public boolean addCategory(Category cate) throws Exception {
		Transaction tx = null;
		boolean status = false;
		try{
			tx = getSession().beginTransaction();
			getSession().save(cate);
			tx.commit();
			status = true;
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行MerServiceImpl类中的addCategory方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return status;
	}

	/**
	 * 删除指定的商品分类 
	 */
	public boolean delCategory(Integer id) throws Exception {
		Transaction tx = null;
		boolean status = false;
		try{
			tx = getSession().beginTransaction();
			//Query q=getSession().createSQLQuery(" delete from category_tb where id=:id ");
			Query hql=getSession().createQuery(" delete from Category where id=:id ");
			hql.setInteger("id", id);
			hql.executeUpdate();
			tx.commit();
			status = true;
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行MerServiceImpl类中的browseCategory方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return status;
	}

	/**
	 * 更新商品分类 
	 */
	public boolean updateCategory(Category cate) throws Exception {
		Transaction tx = null;
		boolean status = false;
		try{
			tx = getSession().beginTransaction();
			/*Query q=getSession().createSQLQuery(
			" UPDATE category_tb "+ 
		            " SET cateName=?, "+
					" cateDesc=? "+
		            " WHERE ID=? "
					);*/
			Query hql=getSession().createQuery(
					" UPDATE Category "+ 
							" SET cateName=?, "+
							" cateDesc=? "+
							" WHERE id=? "
					);
			hql.setString(0, cate.getCateName());
			hql.setString(1, cate.getCateDesc());
			hql.setInteger(2, cate.getId());
			hql.executeUpdate();
			tx.commit();
			status = true;
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行MerServiceImpl类中的updateCategory方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return status;
	}

	/**
	 * 装载指定的商品分类 
	 */
	public Category loadCategory(Integer id) throws Exception {
		Transaction tx = null;
		Category cate = null;
		try{
			tx = getSession().beginTransaction();
			cate = (Category)getSession().get(Category.class, id);
			tx.commit();
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行MerServiceImpl类中的loadCategory方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return cate;
	}

	/**
	 * 浏览商品分类 
	 */
	public List browseCategory() throws Exception {
			Criteria c = getSession().createCriteria(Category.class);		
			c.addOrder(Order.asc("id"));
			List list=c.list();
			getSession().flush();
			getSession().clear();
			getSession().close();
		    return list;
	}

	/**
	 * 新增商品 
	 */
	public boolean addMer(Merchandise mer) throws Exception {
		Transaction tx = null;
		boolean status = false;
		try{
			tx = getSession().beginTransaction();
			getSession().save(mer);
			tx.commit();
			status = true;
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行MerServiceImpl类中的addMer方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return status;
	}

	/**
	 * 删除指定的商品 
	 */
	public boolean delMer(Integer id) throws Exception {
		Transaction tx = null;
		boolean status = false;
		try{
			tx = getSession().beginTransaction();
			//Query q=getSession().createSQLQuery(" delete from merchandise_tb  where id=:id");
			Query hql=getSession().createQuery(" delete from Merchandise  where id=:id");
			hql.setInteger("id", id);
			hql.executeUpdate();
			tx.commit();
			status = true;
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行MerServiceImpl类中的delMer方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return status;
	}

	/**
	 * 更新商品 
	 */
	public boolean updateMer(Merchandise mer) throws Exception {
		Transaction tx = null;
		boolean status = false;
		try{
			tx = getSession().beginTransaction();
			/*Query q = getSession().createSQLQuery(
					" UPDATE merchandise_tb "+ 
                    " SET merName=?, "+
					" price=?, "+
					" sprice=?, "+
					" merModel=?, "+
					" picture=?, "+
					" merDesc=?, "+
					" manufacturer=?, "+
					" leaveFactoryDate=?, "+
					" special=? "+
                    " WHERE ID=? ");*/
			Query hql = getSession().createQuery(
					" UPDATE Merchandise "+ 
							" SET merName=?, "+
							" price=?, "+
							" sprice=?, "+
							" merModel=?, "+
							" picture=?, "+
							" merDesc=?, "+
							" manufacturer=?, "+
							" leaveFactoryDate=?, "+
							" special=?, "+
							" category=? "+
					" WHERE id=? ");
			hql.setString(0, mer.getMerName());
			hql.setDouble(1, mer.getPrice());
			hql.setDouble(2, mer.getSprice());
			hql.setString(3, mer.getMerModel());
			hql.setString(4, mer.getPicture());
			hql.setString(5, mer.getMerDesc());
			hql.setString(6, mer.getManufacturer());
			hql.setString(7, mer.getLeaveFactoryDate());
			hql.setInteger(8, mer.getSpecial());
			hql.setEntity(9, mer.getCategory());
			hql.setInteger(10, mer.getId());
			hql.executeUpdate();
			tx.commit();
			status = true;
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行MerServiceImpl类中的updateMer方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return status;
	}

	/**
	 * 装载指定的商品
	 */
	public Merchandise loadMer(Integer id) throws Exception {
		Transaction tx = null;
		Merchandise mer = null;
		try{
			tx = getSession().beginTransaction();
			mer = (Merchandise)getSession().get(Merchandise.class, id);
			tx.commit();
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行MerServiceImpl类中的loadMer方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return mer;
	}

	/**
	 * 浏览商品 
	 */
	public List browseMer(String hql) throws Exception {
		Transaction tx = null;
		List list = null;
		try{
			Query query = getSession().createQuery(hql);
			tx = getSession().beginTransaction();
			list = query.list();
			tx.commit();
			if (!Hibernate.isInitialized(list))Hibernate.initialize(list);
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行MerServiceImpl类中的browseMer方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return list;
	}

	/**
	 * 分页浏览商品 
	 */
	public List browseMer(int pageSize, int pageNo, int cateId1,int cateId2,
			boolean isSpecial) throws Exception {
		Transaction tx = null;
		List list = null;
		try{
			String hql = "from Merchandise ";
			if (isSpecial){	//特价商品
				hql = hql + " where special=1";
			}else{ //普通商品
				hql = hql + " where special=0";				
			}
			if (cateId1!=0&&cateId2!=0){ //指定类别
				hql = hql + " and category.id between "+cateId1+" and "+cateId2;
			}
			hql = hql + " order by id desc";
			Query query = getSession().createQuery(hql);
			query.setMaxResults(pageSize);
			query.setFirstResult((pageNo-1)*pageSize);
			tx =getSession().beginTransaction();
			list = query.list();
			tx.commit();
			if (!Hibernate.isInitialized(list))Hibernate.initialize(list);
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行MerServiceImpl类中的browseMer方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return list;
	}

	/**
	 * 检索商品
	 */
	public List browseMer(int pageSize, int pageNo, String hql)
			throws Exception {
		Transaction tx = null;
		List list = null;
		try{
			Query query = getSession().createQuery(hql);
			query.setMaxResults(pageSize);
			query.setFirstResult((pageNo-1)*pageSize);
			tx = getSession().beginTransaction();
			list = query.list();
			tx.commit();
			if (!Hibernate.isInitialized(list))Hibernate.initialize(list);
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行MerServiceImpl类中的browseMer方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return list;
	}

	/**
	 * 统计记录条数 
	 */
	public int countRecord(String hql) throws Exception {
		Transaction tx = null;
		int count = 0;
		try{
			tx = getSession().beginTransaction();
			Query query = getSession().createQuery(hql);
			query.setMaxResults(1);
			count = Integer.parseInt(query.uniqueResult().toString());
			tx.commit();
		}catch(Exception ex){
			if(tx!=null)tx.rollback();
			logger.info("在执行MerServiceImpl类中的countRecord方法时出错：\n");
			ex.printStackTrace();
		}finally{
			getSession().flush();
			getSession().clear();
			getSession().close();
		}	
		return count;
	}

	/**
	 * 检查商品分类存在否
	 */
	public boolean chkCategory(String cateName) throws Exception {
		boolean status = true;//true代表数据库已经存在
		Category cate = null;
		Criteria c = getSession().createCriteria(Member.class);
		c.add(Restrictions.eq("cateName", cateName));
		 cate = (Category) c.uniqueResult();
		//mem.setLoginTimes(Integer.valueOf(mem.getLoginTimes().intValue()+1));
		//mem.setLastDate(new Date());
		if(cate==null){
			status=false;
			return status;
		}
		 getSession().flush();
		getSession().clear();
		getSession().close();
		
		return status;
	}
	
}
