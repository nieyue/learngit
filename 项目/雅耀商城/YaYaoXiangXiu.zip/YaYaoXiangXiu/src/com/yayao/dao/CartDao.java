package com.yayao.dao;

import com.yayao.bean.*;
import java.util.*;

public interface CartDao {
	/** 选购商品 */	
	public boolean addCart(Member member,Merchandise mer,int number) throws Exception;
	/** 查看购物车中的选购商品 */
	public List browseCart(Member member) throws Exception;		
	/** 清空购物车 */	
	public boolean clearCart(Member member) throws Exception;		
	/** 调整选购商品的数量 */	
	public boolean modiCart(Integer id,int number) throws Exception;	
	/** 删除已选购商品 */	
	public boolean delCart(Integer id) throws Exception;
	/** 删除购物车 */	
	public boolean delCartSelf(Integer id) throws Exception;
	/** 装载指定会员的购物车 */	
	public Cart loadCart(Member member) throws Exception;
	/** 更新购物车 */	
	public boolean updateCart(Cart cart) throws Exception;
	/** 为选购商品添加订单ID */	
	public boolean insertOrder(Orders order,Cartselectedmer sel) throws Exception;
	
}
