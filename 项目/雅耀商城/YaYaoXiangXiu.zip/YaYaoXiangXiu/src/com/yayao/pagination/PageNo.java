package com.yayao.pagination;
/**
 * 跳转时用到list属性封装类
 * @author yy
 *
 */
public class PageNo {
	  private int pageNumber;     //跳转到第几页  
	  
	    public int getPageNumber() {  
	        return pageNumber;  
	    }  
	  
	    public void setPageNumber(int pageNumber) {  
	        this.pageNumber = pageNumber;  
	    }  
}
