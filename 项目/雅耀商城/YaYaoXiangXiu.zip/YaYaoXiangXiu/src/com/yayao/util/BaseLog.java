package com.yayao.util;

import org.apache.log4j.*;

/** 日志基类 */
public class BaseLog {
	/** 取得日志记录器Logger */
	public static Logger logger = Logger.getLogger(BaseLog.class);
}