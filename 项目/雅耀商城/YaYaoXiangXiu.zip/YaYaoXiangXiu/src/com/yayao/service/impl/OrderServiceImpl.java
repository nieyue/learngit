package com.yayao.service.impl;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.yayao.bean.*;
import com.yayao.dao.CartDao;
import com.yayao.dao.OrderDao;
import com.yayao.service.OrderService;
import com.yayao.util.ActionContextUtil;

@Service("orderService")
public class OrderServiceImpl implements OrderService {
    @Autowired
    @Qualifier("orderDao")
    private OrderDao orderDao;
    @Autowired
    @Qualifier("cartDao")
    private CartDao cartDao;
	@Override
	public boolean addOrder(Orders order) throws Exception {
		boolean status = orderDao.addOrder(order);
		return status;
	}

	@Override
	public List browseOrder(Member member) throws Exception {
			
		List orders = orderDao.browseOrder(member);
		
				return orders;
	}

	@Override
	public List browseOrder() throws Exception {
		List list = orderDao.browseOrder();
		return list;
	}

	/**
	 * 浏览当前会员的所有订单的选购商品
	 */
	public List browseOrderMer() throws Exception {
		Map session = ActionContextUtil.getSession();
		Member member=(Member)session.get("Member");
		
		List list=new ArrayList();
		List orders = orderDao.browseOrder(member);
		for (int i = 0; i < orders.size(); i++) {
			Orders o=(Orders)orders.get(i);
			List om = orderDao.browseOrderMer(o);
			for (int j = 0; j < om.size(); j++) {
				Cartselectedmer cartselectedmer=(Cartselectedmer) om.get(j);
				list.add(cartselectedmer);
			}
		}
		session.remove("orderMerList");
		session.put("orderMerList", list);
		return list;
	}

	@Override
	public boolean delOrder(Integer id) throws Exception {
		boolean status = orderDao.delOrder(id);
		return status;
	}

	@Override
	public Orders loadOrder(Integer id) throws Exception {
		Orders order = orderDao.loadOrder(id);
		return order;
	}

	@Override
	public boolean updateOrder(Orders order) throws Exception {
		boolean status = orderDao.updateOrder(order);
		return status;
	}

	@Override
	public List browseOrderMer(Orders order) throws Exception {
		List list = orderDao.browseOrderMer(order);
		return list;
	}

	
}
