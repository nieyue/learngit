package com.yayao.service.impl;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.yayao.bean.*;
import com.yayao.dao.CartDao;
import com.yayao.dao.MerDao;
import com.yayao.service.CartService;
import com.yayao.util.ActionContextUtil;
@Service("cartService")
public class CartServiceImpl implements CartService {

	@Autowired
	@Qualifier("cartDao")
	private CartDao cartDao;
	@Autowired
	@Qualifier("merDao")
	private MerDao merDao;

	@Override
	public boolean addCart(Member member, Merchandise mer, int number)
			throws Exception {
		boolean s = cartDao.addCart(member, mer, number);
		
		return s;
	}

	@Override
	public List browseCart(Member member) throws Exception {
		 Map session = ActionContextUtil.getSession();
		List l=cartDao.browseCart(member);
		List list=new ArrayList();
		Double totleMoney=0.0;
		if(l!=null){
		for (int i = 0; i < l.size(); i++) {
			Cartselectedmer sel = (Cartselectedmer) l.get(i);
			//Merchandise mer=merDao.loadMer(sel.getMerchandise().getId());
			totleMoney+=sel.getMoney();
			list.add(sel);
		}
		session.put("cartSelectedMerList", list);
		session.put("totalMoney", totleMoney);
		}
		return list;
		
	}

	@Override
	public boolean clearCart(Member member) throws Exception {
		boolean s=cartDao.clearCart(member);
		return s;
	}

	@Override
	public boolean modiCart(Integer id, int number) throws Exception {
		boolean s=cartDao.modiCart(id, number);
		return s;
	}

	@Override
	public boolean delCart(Integer id) throws Exception {
		boolean s = cartDao.delCart(id);
		return s;
	}

	@Override
	public Cart loadCart(Member member) throws Exception {
		Cart c = cartDao.loadCart(member);
		return c;
	}

	@Override
	public boolean updateCart(Cart cart) throws Exception {
		boolean s = cartDao.updateCart(cart);
		return s;
	}

	@Override
	public boolean insertOrder(Orders order, Cartselectedmer sel)
			throws Exception {
		boolean s = cartDao.insertOrder(order, sel);
		return s;
	}

	@Override
	public boolean delCartSelf(Integer id) throws Exception {
	     boolean s = cartDao.delCartSelf(id);
		return s;
	}

}
