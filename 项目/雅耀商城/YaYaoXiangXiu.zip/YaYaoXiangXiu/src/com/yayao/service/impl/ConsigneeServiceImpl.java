package com.yayao.service.impl;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.stereotype.Service;

import com.yayao.bean.Consignee;
import com.yayao.bean.Member;
import com.yayao.dao.ConsigneeDao;

import com.yayao.service.ConsigneeService;
import com.yayao.util.ActionContextUtil;
import com.yayao.util.BaseLog;
@Service("consigneeService")
public class ConsigneeServiceImpl extends BaseLog implements ConsigneeService {
	
	@Autowired
	@Qualifier("consigneeDao")
	private ConsigneeDao consigneeDao;
	/**
	 * 增加收货人
	 */
	@Override
	public boolean addConsignee(Consignee consignee) throws Exception {
		boolean status=consigneeDao.addConsignee(consignee);
		browseConsignee();
		 return status;
	}
	
	/**
	 * 修改收货人信息
	 */
	@Override
	public boolean updateConsignee(Consignee consignee) throws Exception {
		boolean status=consigneeDao.updateConsignee(consignee);
		browseConsignee();
		return status;
	}

	/**
	 * 浏览当前人的所有收货信息
	 */
	@Override
	public List browseConsignee() throws Exception {
		//List list=consigneeDao.browseConsignee();
		Member member =(Member)ActionContextUtil.getSession().get("Member");
		//存储当前收货人信息
		List list=new ArrayList();
		//浏览所有人收货信息
		List newconsignees=consigneeDao.browseConsignee();
		if(newconsignees!=null){
		for (int j = 0; j < newconsignees.size(); j++) {
			Consignee con = (Consignee) newconsignees.get(j);
			if((con.getMember().getId()).equals(member.getId())){
				list.add(con);
			}
		}
		
		ActionContextUtil.getSession().remove("conList");
		//存储当前收货人信息
		ActionContextUtil.getSession().put("conList", list);
		}
		return list;
	}

	/**
	 * 删除收货人信息
	 */
	@Override
	public boolean delConsignee(Integer id) throws Exception {
		boolean status=consigneeDao.delConsignee(id);
		browseConsignee();
			return status;
	}
	
	/**
	 * 装载收货人信息
	 */
	@Override
	public Consignee loadConsignee(Integer id) throws Exception {
		Consignee consignee=consigneeDao.loadConsignee(id);
		return consignee;
	}

}
