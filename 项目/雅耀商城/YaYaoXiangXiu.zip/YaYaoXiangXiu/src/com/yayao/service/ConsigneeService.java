package com.yayao.service;

import java.util.*;
import com.yayao.bean.*;

public interface ConsigneeService {
	
	/** 新增收货人 */	
	public boolean addConsignee(Consignee consignee) throws Exception;
	/** 修改收货人信息 */	
	public boolean updateConsignee(Consignee consignee) throws Exception;
	
	/** 浏览收货人信息*/
	public List browseConsignee() throws Exception;
	/** 删除收货人信息*/	
	public boolean delConsignee(Integer id) throws Exception;
	/**装载收货人信息 */	
	public Consignee loadConsignee(Integer id) throws Exception;	
	
}
