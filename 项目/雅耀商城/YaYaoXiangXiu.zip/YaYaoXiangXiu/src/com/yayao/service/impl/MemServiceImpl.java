package com.yayao.service.impl;

import java.util.*;

import org.apache.struts2.ServletActionContext;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.yayao.bean.*;
import com.yayao.dao.ConsigneeDao;
import com.yayao.dao.MemDao;
import com.yayao.service.CommentService;
import com.yayao.service.ConsigneeService;
import com.yayao.service.MemService;
import com.yayao.util.*;
@Service("memService")
public class MemServiceImpl implements MemService {

	@Autowired
	@Qualifier("memDao")
	private MemDao memDao;
	
	/** 新增注册会员 */
	public boolean addMember(Member member) throws Exception {
		member.setLoginTimes(0);
		member.setRegDate(DateUtil.getCurrentTime());
		Memberlevel ml=memDao.loadMemberLevel(1);
		member.setMemberlevel(ml);
		member.setLastDate(DateUtil.getCurrentTime());
		member.setIsLogin(new Integer(0));
		boolean status=memDao.addMember(member);
		return status;
	}

	/** 检测登录帐号是否有效 */
	public boolean chkLoginName(String loginName) throws Exception {
		boolean status=memDao.chkLoginName(loginName);
		return status;
	}


	/** 会员登录 */
	public Member memLogin(String loginName, String loginPwd) throws Exception {
	Member member=memDao.memLogin(loginName, loginPwd);
	if(member!=null){
	Integer i= member.getLoginTimes();
	i++;
	member.setLoginTimes(i);
	member.setLastDate(DateUtil.getCurrentTime());
	member.setIsLogin(1);
	//修改数据库
	memDao.updateMember(member);
	}
		return member;
	}

	/** 修改注册会员 */
	public boolean updateMember(Member member) throws Exception {
		
		boolean status=memDao.updateMember(member);
		return status;
	}

	/** 浏览注册会员*/
	public List browseMember() throws Exception {
		
		//浏览所有会员
		List members=memDao.browseMember();
		if(members!=null){
		
		ActionContextUtil.getSession().remove("memList");
		//存储所有会员
		ActionContextUtil.getSession().put("memList", members);
		}
		return members;
	}

	/** 删除注册会员 */
	public boolean delMember(Integer id) throws Exception {
		boolean status=memDao.delMember(id);
		return status;
	}

	/**装载注册会员 */
	public Member loadMember(Integer id) throws Exception {
		Member member=memDao.loadMember(id);
		return member;
	}

	/**浏览注册会员等级 */
	public List browseMemberLevel() throws Exception {
		List l = memDao.browseMemberLevel();
		return l;
	}

	/**装载注册会员 级别*/
	public Memberlevel loadMemberLevel(Integer id) throws Exception {
		Memberlevel ml = memDao.loadMemberLevel(id);
		return ml;
	}

	/** 查询注册会员  */
	public List searchMem(String hql) throws Exception {
		List list = memDao.searchMem(hql);
		return list;
	}

	/**
	 * 找回账户
	 */
	public Member RetrieveAccount(String loginName, String email)
			throws Exception {
		Member m = memDao.RetrieveAccount(loginName, email);
		return m;
	}

	
}
