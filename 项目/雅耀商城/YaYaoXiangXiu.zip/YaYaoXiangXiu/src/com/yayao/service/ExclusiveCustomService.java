package com.yayao.service;

import java.util.*;

import com.yayao.bean.*;

public interface ExclusiveCustomService {
	
	/** 新增定制 */	
	public boolean addExclusiveCustom(ExclusiveCustom exclusiveCustom) throws Exception;
	/** 修改定制信息 */	
	public boolean updateExclusiveCustom(ExclusiveCustom exclusiveCustom) throws Exception;
	
	/** 浏览所有定制信息*/
	public List browseAllExclusiveCustom() throws Exception;
	/** 浏览当前会员定制信息*/
	public List browseExclusiveCustom() throws Exception;
	/** 删除定制信息*/	
	public boolean delExclusiveCustom(Integer id) throws Exception;
	/**装载定制信息 */	
	public ExclusiveCustom loadExclusiveCustom(Integer id) throws Exception;	
	/**查询定制订单 */	
	public List searchExclusiveCustom(String hql) throws Exception;	
}
