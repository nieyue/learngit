package com.yayao.service;

import com.yayao.bean.*;

import java.util.*;

public interface CommentService {
	/** 新增留言 */	
	public boolean addComment(Comment comment) throws Exception;
	/** 分页浏览所有留言 */
	public List browseComment(int pageSize,int pageNo) throws Exception;
	/** 分页浏览当前商品的所有留言 */
	public List browseComment(int pageSize,int pageNo,Merchandise merchandise) throws Exception;
	/** 浏览当前人的定制订单留言 */
	public List browseMemCustomComment(Member member) throws Exception;
	/** 浏览当前人的订单留言 */
	public List browseMemMerComment(Member member) throws Exception;
	/** 浏览每个商品所有留言 */
	public List browseMerComment(Merchandise merchandise) throws Exception;
	/** 统计留言条数 */
	public int countComment() throws Exception;	
	/** 统计当前商品的留言条数 */
	public int countComment(Merchandise merchandise) throws Exception;
	/** 删除留言 */	
	public boolean delComment(Integer id) throws Exception;	
	/** 装载留言 */	
	public Comment loadComment(Integer id) throws Exception;
	/** 回复留言 */	
	public boolean updateComment(Comment comment) throws Exception;
}
